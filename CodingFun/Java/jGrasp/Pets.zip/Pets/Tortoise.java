public class Tortoise extends Pet {

    /**
     * Default constructor
     */
    public Tortoise() {
        super(25.0);
        setIsPredator(false);
        setName("No name");
        setNoise("No noise");
    }

    /**
     * Custom constructor
     */
    public Tortoise(String name, String noise) {
        this();
        setName(name);
        setNoise(noise);
    }

    public void snap() {
        System.out.println(super.getName() + " is ferociously snapping in every direction!");
    }

    @Override
    public String toString() {
        return (super.getName() + " the Tortoise");
    }
}
