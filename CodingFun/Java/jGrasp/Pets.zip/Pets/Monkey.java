public class Monkey extends Pet {

    /**
     * Default constructor
     */
    public Monkey() {
        super(45.0);
        setIsPredator(false);
        setName("No name");
        setNoise("No noise");
    }

    /**
     * Custom constructor
     */
    public Monkey(String name, String noise) {
        this();
        setName(name);
        setNoise(noise);
    }

    public void climb() {
        System.out.println(super.getName() + " climbed a tree.");
    }

    @Override
    public String toString() {
        return (super.getName() + " the Monkey");
    }
}
