public class Pet {
    private String name;
    private double weight;
    private boolean isPredator;
    private String noise;

    /**
     * Default constructor. No information is known for a generic pet upon creation, so
     * we'll leave this blank.
     */
    public Pet() {
        this.name = null;
        this.weight = 0.0;
    }

    public Pet(double defaultWeight) {
        this.weight = defaultWeight;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getWeight() {
        return this.weight;
    }

    /**
     * 
     * @param amount The amount of food give to the pet in lbs.
     */
    public void feed(double amount) {
        this.weight += (0.1 * amount);
    }

    public Boolean getIsPredator() {
        return this.isPredator;
    }

    public void setIsPredator(Boolean isPredator) {
        this.isPredator = isPredator;
    }

    public String getNoise() {
        return this.noise;
    }

    public void setNoise(String noise) {
        this.noise = noise;
    }
}
