import java.util.concurrent.TimeUnit;
import java.util.Random;

public class PetMain {
    public static void main(String[] args) throws InterruptedException {
        /* Download 2 students' specific pet Java files (ex. Dog.java, Cat.java). Use 1 of those
        student's Pet.java file. Make changes needed to get it to run. If you can't, just use
        the defaults already made (Tortoise.java) */

        Pet pet1 = new Tortoise("Harry", "SNAP SNAP");
        Pet pet2 = new Monkey("Itchy", "ooh ooh AAH AAH");

        /*
        for(int i = 0; i < 1000; i++) {
            pet2.feed(1);
        }
        */
        
        fightToDeath(pet1, pet2);
    }

    public static void fightToDeath(Pet pet1, Pet pet2) throws InterruptedException {
        Random r = new Random();
        double pet1Ability = determineAbility(pet1);
        double pet2Ability = determineAbility(pet2);

        //Make noises while fighting
        for(int i = 0; i < r.nextInt(4) + 1; i++) {
            System.out.println(pet1.getNoise());
            TimeUnit.SECONDS.sleep(1);
            System.out.println(pet2.getNoise());
            TimeUnit.SECONDS.sleep(1);
        }
        System.out.println();

        double fightingAbilityRatio = pet1Ability / pet2Ability;
        double chanceOfPet1Winning;
        if(fightingAbilityRatio <= 0.1) {
            chanceOfPet1Winning = 0.1;
        } else if(fightingAbilityRatio <= 0.5) {
            chanceOfPet1Winning = 0.3;
        } else if(fightingAbilityRatio <= 1.5) {
            chanceOfPet1Winning = 0.5;
        } else if(fightingAbilityRatio <= 2.0) {
            chanceOfPet1Winning = 0.7;
        } else {
            chanceOfPet1Winning = 0.9;
        }

        //Fight
        if(r.nextDouble() <= chanceOfPet1Winning) {
            System.out.println(pet2.getNoise().toLowerCase() + "...");
            System.out.println(pet2.toString() + " has died.");
        } else {
            System.out.println(pet1.getNoise().toLowerCase() + "...");
            System.out.println(pet1.toString() + " has died.");
        }
    }

    public static double determineAbility(Pet pet) {
        if(pet.getIsPredator()) {
            return pet.getWeight() * 1.5;
        } else {
            return pet.getWeight();
        }
    }
}
